function matematicas(){
    document.write("log 1000: " + Math.log(1000) + "<br/>");
    document.write("exp 3: " + Math.exp(3) + "<br/>");
    document.write("raiz 16: " + Math.sqrt(16) + "<br/>");
    document.write("potencia 2 elevado 3: " + Math.pow(2,3) + "<br/>");
    document.write("absoluto -6432: " + Math.abs(-6432) + "<br/>");
    document.write("absoluto 6432: " + Math.abs(6432) + "<br/>");
    document.write("floor 9.65: " + Math.floor(9.65) + "<br/>");
    document.write("floor -9.65: " + Math.floor(-9.65) + "<br/>");
    document.write("floor 9.35: " + Math.floor(9.35) + "<br/>");
    document.write("ceil 9.65: " + Math.ceil(9.65) + "<br/>");
    document.write("ceil -9.65: " + Math.ceil(-9.65) + "<br/>");
    document.write("ceil 9.35: " + Math.ceil(9.35) + "<br/>");
    document.write("round 9.65: " + Math.round(9.65) + "<br/>");
    document.write("round -9.65: " + Math.round(-9.65) + "<br/>");
    document.write("round 9.35: " + Math.round(9.35) + "<br/>");
    document.write("round 9.5: " + Math.round(9.5) + "<br/>");
    document.write("round -9.5: " + Math.round(-9.5) + "<br/>");
    document.write("random: " + Math.random() + "<br/>");
    document.write("random 100: " + Math.random() *100 + "<br/>");
    document.write("cos: " + Math.cos(Math.PI * 2) + "<br/>");
    document.write("max: " + Math.max(4,8,1,3,9) + "<br/>");
    document.write("min: " + Math.min(4,8,1,3,9) + "<br/>");

    with (Math){
        document.write(((log(1000) * PI / cos(PI)) * pow(3,6))+ "<br/>");
    }
}

function textos(){
    var texto = "Esto es un texto para probar los metodos de la clase String";

    document.write("fromCharCode 128: " + String.fromCharCode(128) + "<br/>");
    document.write("charCodeAt letra t: " + texto.charCodeAt(11) + "<br/>");
    document.write("indexOf p: " + texto.indexOf("p") + "<br/>");
    document.write("indexOf siguiente p: " + texto.indexOf("p", 18) + "<br/>");
    document.write("indexOf @: " + texto.indexOf("@") + "<br/>");
    document.write("lastIndexOf e: " + texto.lastIndexOf("e") + "<br/>");
    document.write("length: " + texto.length + "<br/>");
    document.write("substr 3,9: " + texto.substr(3,9) + "<br/>");
    document.write("slice 3,9: " + texto.slice(3,9) + "<br/>");
    document.write("slice 3: " + texto.slice(3) + "<br/>");
    document.write("substring 3,9: " + texto.substring(3,9) + "<br/>");
    document.write("toLowerCase: " + texto.toLowerCase() + "<br/>");
    document.write("toUpperCase: " + texto.toUpperCase() + "<br/>");

    var palabras = texto.split(" ");
    document.write("Numero palabras: " + palabras.length + "<br/>");

    var datos = "13/6/2022".split("/");
    document.write("Dia: " + datos[0] + "<br/>");
    document.write("Mes: " + datos[1] + "<br/>");
    document.write("Año: " + datos[2] + "<br/>");

    document.write("Replace: " + texto.replace("metodos","métodos") + "<br/>");
    document.write("Replace: " + texto.replace("a","A") + "<br/>");
    document.write("ReplaceAll: " + texto.replaceAll("a","A") + "<br/>");
   
}

function fechas(){
    var hoy = new Date();

    document.write("getTime: " + hoy.getTime() + "<br/>");
    document.write("getTimezoneOffset: " + hoy.getTimezoneOffset() + "<br/>");
    document.write("getDay: " + hoy.getDay() + "<br/>");
    document.write("getDate: " + hoy.getDate() + "<br/>");
    document.write("getMonth: " + hoy.getMonth() + "<br/>");
    document.write("getYear: " + hoy.getYear() + "<br/>");
    document.write("getFullYear: " + hoy.getFullYear() + "<br/>");

    document.write(hoy.getDate() + "/" + (hoy.getMonth()+1) + "/" + hoy.getFullYear() + "<br/>");

    document.write(sumarDias(hoy, 20)  + "<br/>");
    document.write(sumarDias(hoy, -10)  + "<br/>");
    document.write(sumarMes(new Date(), 2)  + "<br/>");
    document.write(sumarAnyos(new Date(), 1)  + "<br/>");
    
    // restar fechas (dias de diferencia)
    // calcular el ultimo dia del mes anterior a la fecha actual, Fecha cierre
    // ver si son laborables o no (1-5)
    // calcular dias trabajados (diferencia de fechas), quitar las vacaciones y fines de semana
    // calcular si un año es bisiesto

    // horas, minutos, segundos y milisegundos
}

function sumarDias(fecha, dias){
    fecha.setDate(fecha.getDate() + dias);
    return fecha;
}

function sumarMes(fecha, meses){
    fecha.setMonth(fecha.getMonth() + meses);
    return fecha;
}

function sumarAnyos(fecha, anyos){
    fecha.setFullYear(fecha.getFullYear() + anyos);
    return fecha;
}
