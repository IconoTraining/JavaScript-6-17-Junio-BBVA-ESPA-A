function matematicas(){
    document.write("log 1000: " + Math.log(1000) + "<br/>");
    document.write("exp 3: " + Math.exp(3) + "<br/>");
    document.write("raiz 16: " + Math.sqrt(16) + "<br/>");
    document.write("potencia 2 elevado 3: " + Math.pow(2,3) + "<br/>");
    document.write("absoluto -6432: " + Math.abs(-6432) + "<br/>");
    document.write("absoluto 6432: " + Math.abs(6432) + "<br/>");
    document.write("floor 9.65: " + Math.floor(9.65) + "<br/>");
    document.write("floor -9.65: " + Math.floor(-9.65) + "<br/>");
    document.write("floor 9.35: " + Math.floor(9.35) + "<br/>");
    document.write("ceil 9.65: " + Math.ceil(9.65) + "<br/>");
    document.write("ceil -9.65: " + Math.ceil(-9.65) + "<br/>");
    document.write("ceil 9.35: " + Math.ceil(9.35) + "<br/>");
    document.write("round 9.65: " + Math.round(9.65) + "<br/>");
    document.write("round -9.65: " + Math.round(-9.65) + "<br/>");
    document.write("round 9.35: " + Math.round(9.35) + "<br/>");
    document.write("round 9.5: " + Math.round(9.5) + "<br/>");
    document.write("round -9.5: " + Math.round(-9.5) + "<br/>");
    document.write("random: " + Math.random() + "<br/>");
    document.write("random 100: " + Math.random() *100 + "<br/>");
    document.write("cos: " + Math.cos(Math.PI * 2) + "<br/>");
    document.write("max: " + Math.max(4,8,1,3,9) + "<br/>");
    document.write("min: " + Math.min(4,8,1,3,9) + "<br/>");

    with (Math){
        document.write(((log(1000) * E / cos(PI)) * pow(3,6))+ "<br/>");
    }
}

function textos(){
    var texto = "Esto es un texto para probar los metodos de la clase String";

    document.write("fromCharCode 128: " + String.fromCharCode(128) + "<br/>");
    document.write("charCodeAt letra t: " + texto.charCodeAt(11) + "<br/>");
    document.write("indexOf p: " + texto.indexOf("p") + "<br/>");
    document.write("indexOf siguiente p: " + texto.indexOf("p", 18) + "<br/>");
    document.write("indexOf @: " + texto.indexOf("@") + "<br/>");
    document.write("lastIndexOf e: " + texto.lastIndexOf("e") + "<br/>");
    document.write("length: " + texto.length + "<br/>");
    document.write("substr 3,9: " + texto.substr(3,9) + "<br/>");
    document.write("slice 3,9: " + texto.slice(3,9) + "<br/>");
    document.write("slice 3: " + texto.slice(3) + "<br/>");
    document.write("substring 3,9: " + texto.substring(3,9) + "<br/>");
    document.write("toLowerCase: " + texto.toLowerCase() + "<br/>");
    document.write("toUpperCase: " + texto.toUpperCase() + "<br/>");

    var palabras = texto.split(" ");
    document.write("Numero palabras: " + palabras.length + "<br/>");

    var datos = "13/6/2022".split("/");
    document.write("Dia: " + datos[0] + "<br/>");
    document.write("Mes: " + datos[1] + "<br/>");
    document.write("Año: " + datos[2] + "<br/>");

    document.write("Replace: " + texto.replace("metodos","métodos") + "<br/>");
    document.write("Replace: " + texto.replace("a","A") + "<br/>");
    document.write("ReplaceAll: " + texto.replaceAll("a","A") + "<br/>");
   
}

function fechas(){
    var hoy = new Date();

    document.write("getTime: " + hoy.getTime() + "<br/>");
    document.write("getTimezoneOffset: " + hoy.getTimezoneOffset() + "<br/>");
    document.write("getDay: " + hoy.getDay() + "<br/>");
    document.write("getDate: " + hoy.getDate() + "<br/>");
    document.write("getMonth: " + hoy.getMonth() + "<br/>");
    document.write("getYear: " + hoy.getYear() + "<br/>");
    document.write("getFullYear: " + hoy.getFullYear() + "<br/>");

    document.write(hoy.getDate() + "/" + (hoy.getMonth()+1) + "/" + hoy.getFullYear() + "<br/>");

    document.write(sumarDias(hoy, 20)  + "<br/>");
    document.write(sumarDias(hoy, -10)  + "<br/>");
    document.write(sumarMes(new Date(), 2)  + "<br/>");
    document.write(sumarAnyos(new Date(), 1)  + "<br/>");
    
    // restar fechas (dias de diferencia)
    var dia1 = new Date("08/25/2021");
    var dia2 = new Date("08/25/2022");
    var diferencia = Math.abs(dia2-dia1);
    var dias_diferencia = diferencia / (1000 * 60 * 60 * 24);
    document.write("diferencia de fechas: " + dias_diferencia + "<br/>"); 

    // calcular el ultimo dia del mes anterior a la fecha actual, Fecha cierre
    var hoy = new Date();
    var dia1 = hoy.setDate(1);
    dia1 = new Date(dia1);
    document.write("Ultimo dia: " + sumarDias(dia1, -1) + "<br/>");

    // ver si son laborables o no (1-5)
    var laborable = new Date("08/25/2022");
    document.write(laborable + " es laborable?" + esLaborable(laborable) +" <br/>");

    // calcular dias trabajados (diferencia de fechas), quitar las vacaciones y fines de semana

    // calcular si un año es bisiesto
    document.write("2001 es bisiesto: " + esBisiesto(2001) + "<br/>"); 
    document.write("2004 es bisiesto: " + esBisiesto(2004) + "<br/>"); 
    document.write("2100 es bisiesto: " + esBisiesto(2100) + "<br/>"); 
    document.write("2431 es bisiesto: " + esBisiesto(2431) + "<br/>"); 

    // horas, minutos, segundos y milisegundos
    document.write("getHours: " + hoy.getHours() + "<br/>"); 
    document.write("getMinutes: " + hoy.getMinutes() + "<br/>");
    document.write("getSeconds: " + hoy.getSeconds() + "<br/>");
    document.write("getMilliseconds: " + hoy.getMilliseconds() + "<br/>");       
}

function esLaborable(fecha){
    if (fecha.getDay !== 0 && fecha.getDay !== 6){
        return true;
    } else {
        return false;
    }
}

// 1.- Si el año es divisible por 400, es bisiesto
// 2.- Si es divisible por 100, NO es bisiesto
// 3.- Si es divisible por 4, es bisiesto
function esBisiesto(anyo){
    if (anyo % 400 == 0){
        return true;
    } else if(anyo % 100 == 0){
        return false;
    } else if (anyo % 4 == 0){
        return true;
    } else {
        return false;
    }
}

function sumarDias(fecha, dias){
    fecha.setDate(fecha.getDate() + dias);
    return fecha;
}

function sumarMes(fecha, meses){
    fecha.setMonth(fecha.getMonth() + meses);
    return fecha;
}

function sumarAnyos(fecha, anyos){
    fecha.setFullYear(fecha.getFullYear() + anyos);
    return fecha;
}
