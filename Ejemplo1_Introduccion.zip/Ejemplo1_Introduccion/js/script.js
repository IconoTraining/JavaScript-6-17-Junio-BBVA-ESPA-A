// Solicitar datos al usuario
var nombreUsuario = window.prompt("Introduce tu nombre");