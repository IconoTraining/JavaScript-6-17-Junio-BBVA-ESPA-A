function cargarProvincias(){
    // Crear un array con los nombres de las provincias
    var arrayProvincias = new Array("Madrid","Valencia","Sevilla","Toledo");

    // Buscar en la pagina donde tengo el select provincias
    var selectProvincias = document.getElementById("provincias");

    for (var indice in arrayProvincias){
        selectProvincias.innerHTML += "<option value=" + indice + ">" +
            arrayProvincias[indice] + "</option>";
    }
}


function cargarPoblaciones(){
    // selectedIndex devuelve el orden de las opciones
    var seleccionado = document.getElementById("provincias").selectedIndex;

    var arrayPoblaciones = null;

    switch (seleccionado){
        case 1:
            arrayPoblaciones = ["Getafe", "Parla", "Torrelodones"];
            break;
        case 2:
            arrayPoblaciones = ["Gandia", "Oliva"];
            break;
        case 3:
            arrayPoblaciones = ["Dos Hermanas", "Espartinas", "Palacios"];
            break;
        case 4:
            arrayPoblaciones = ["Talavera", "Trillo", "Cebolla"];
            break;
        default:
            break;
    }

    // Limpiar las poblaciones anteriores
    document.getElementById("poblaciones").innerHTML = "<option> -- Selecciona -- </option>";

    for (var indice in arrayPoblaciones){
        document.getElementById("poblaciones").innerHTML += "<option value=" + indice + ">" +
            arrayPoblaciones[indice] + "</option>";
    }
}