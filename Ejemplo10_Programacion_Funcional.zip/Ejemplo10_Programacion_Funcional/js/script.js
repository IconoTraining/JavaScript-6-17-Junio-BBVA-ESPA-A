var nombres = ["Pepe", "Juan", "Antonio", "Laura", "Sofia", "Ismael"];

// coleccion.forEach(que_recibo => { como lo proceso });
nombres.forEach(nombre => {
    console.log(nombre);
});

// map sirve para transformar datos en una coleccion
// coleccion.map(que_recibo =>  que cambio le aplico );
var mayusculas = nombres.map(nombre => nombre.toUpperCase());
console.log(mayusculas);
console.log(nombres);

// filter sirve para filtrar elementos de una coleccion a traves de una condicion
// si la condicion devuelve true -> me lo quedo, si es false -> lo descarto
// coleccion.filter(que_recibo => condicion );
var nombresLargos = nombres.filter(nombre => nombre.length > 5);
console.log(nombresLargos);

// reduce, aplica un algoritmo a cada elemento y devuelve un unico valor
// coleccion.reduce((acumulador,que_recibo) => algoritomo a aplicar );
var cadena = nombres.reduce((acum, nombre) => acum + "-" + nombre);
console.log(cadena);

// Ejercicio
var numeros = [8,1,5,2,9,3,7,4];

// Con map multiplicar el numero por 3
// con filter quedaros con los numeros impares
// Con reducer obtener la suma
var multiplos = numeros.map(num => num * 3);
console.log(multiplos);

var impares = numeros.filter(num => num % 2 == 1);
console.log(impares);

var suma = numeros.reduce((acum, num) => acum + num);
console.log(suma);

// encadenar funciones
var resultado = numeros
    .map(num => num * 3)
    .filter(num => num % 2 == 1)
    .reduce((acum, num) => acum + num);
console.log(resultado);

var cadenaMayusculas = nombres
    .map(nombre => nombre.toUpperCase())
    .filter(nombre => nombre.length > 5)
    .reduce((acum, nombre) => acum + "-" + nombre );
console.log(cadenaMayusculas);