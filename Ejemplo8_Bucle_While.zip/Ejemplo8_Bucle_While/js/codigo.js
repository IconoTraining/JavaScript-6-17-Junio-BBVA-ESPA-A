/*
    EJEMPLO 1
    Mostrar los numeros del 1 al 10

var numero = 1;
while(numero <= 10){
    document.write(numero + "<br/>");
    numero++;
}
*/

/*
    EJEMPLO 2
    Vamos a solicitar el password al usuario hasta que acierte que es curso

do{
    var pw = window.prompt("Introduce password");
}while( pw != "curso");
*/

/*
    EJEMPLO 3
    Vamos a solicitar el password al usuario hasta que acierte que es curso
    pero solo tiene 3 oportunidades
    break; da por terminado el bucle


var oportunidades = 3
do{
    var pw = window.prompt("Introduce password");
    oportunidades--;
    if (pw == "curso"){
        alert("Password correcta");
        break;
    } else {
        alert("No era esa, te quedan " + oportunidades + " oportunidades");
    }
}while( oportunidades > 0);


for(var intento = 1; intento <= 3; intento++){
    var pw = window.prompt("Introduce password");
    if (pw == "curso"){
        alert("Password correcta");
        break;
    } else {
        alert("No era esa, te quedan " + (3-intento) + " oportunidades");
    }
}
*/

/*
    EJEMPLO 4
    Se trata de adivinar un numero aleatorio entre 1 y 10 dando pistas al usuario
    Math.random() genera un numero aleatorio entre 0 y 1, pero sin llegar a 1
*/

/*var aleatorio = Math.random();
console.log(aleatorio);
aleatorio = aleatorio * 10;
console.log(aleatorio);
aleatorio = parseInt(aleatorio);
console.log(aleatorio);
aleatorio = aleatorio + 1;
console.log(aleatorio);

var aleatorio = parseInt(Math.random() * 10) + 1;
//console.log(aleatorio);
var acertado = false;

while(!acertado){
    var numero = parseInt(window.prompt("Adivina numero 1-10:"));

    if (numero < aleatorio){
        alert("Te has quedado corto, prueba con un numero mayor");
    } else if (numero > aleatorio){
        alert("Te has pasado, prueba con un numero menor");
    } else if (numero === aleatorio){
        alert("Lo has adivinado");
        acertado = true;
    } else {
        alert("Debes introducir un numero");
    }
}

*/

/*
    EJEMPLO continue
    Mostrar solo los numeros impares entre 1 y 10
*/
var numero = 0;
while (numero++ < 10){
    //numero++;
    if (numero % 2 == 0) continue;   // si es par avanzo al siguiente numero
    document.write(numero + "<br/>");
    
}