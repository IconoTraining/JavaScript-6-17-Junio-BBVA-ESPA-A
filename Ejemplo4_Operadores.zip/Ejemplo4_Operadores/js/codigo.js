// Operadores aritmeticos 
var num1 = 7;
var num2 = 2;

console.log("Suma: " + (num1 + num2));
console.log("Resta: " + (num1 - num2));
console.log("Multiplicacion: " + (num1 * num2));
console.log("Division: " + (num1 / num2));
console.log("Division entera: " + (~~(num1 / num2)));
console.log("Resto de la division: " + (num1 % num2));
console.log("Cambio de signo: " + (-num1));


// Operadores logicos
var nombre1 = "Juan";
var nombre2 = "Pepe";

console.log("AND: " + ( (nombre1=="Juan") && (nombre2=="Pepe")  ));
console.log("OR: " + ( (nombre1=="juannnnnn") || (nombre2=="Pepe")  ));
console.log("NOT: " + ( !(nombre1=="juannnnnn")));
console.log("NOT: " + ( !(nombre1=="Juan")));


// Operadores relacionales
console.log("Igualdad: " + (num1 == 7));
console.log("Desigualdad: " + (num1 != 7));
console.log("Mayor: " + (num1 > 7));
console.log("Mayor o igual: " + (num1 >= 7));
console.log("Menor: " + (num1 < 7));
console.log("Menor o igual: " + (num1 <= 7));

// Igualdad o desigualdad extricta
console.log("Igualdad: " + (num1 == "7"));
console.log("Igualdad extricta: " + (num1 === "7"));
console.log("Desigualdad: " + (num1 != "7"));
console.log("Desigualdad extricta: " + (num1 !== "7"));

// Operadores de asignacion
var numero = 5;
console.log("Numero: " + numero);
numero += 5;   // numero = numero + 5
console.log("Numero: " + numero);
numero -= 5;   // numero = numero - 5
console.log("Numero: " + numero);
numero *= 5;   // numero = numero * 5
console.log("Numero: " + numero);
numero /= 5;   // numero = numero / 5
console.log("Numero: " + numero);
numero %= 5;   // numero = numero % 5
console.log("Numero: " + numero);

// Incrementos y decrementos
var i = 6;

i++;   // incremento
++i;
i--;   // decremento
--i;

var j = i++;  // post-incremento   1º asigna, 2º incrementa j=6 i=7
i=6;
var j = ++i;  // pre-incremento    1º incrementa, 2º asigna j=7 i=7 

i=6;
var j = i--;  // post-decremento   1º asigno, 2º decrementa j=6 i=5
i=6;
var j = --i;  // pre-decremento    1º decremento, 2º asigno j=5 i=5