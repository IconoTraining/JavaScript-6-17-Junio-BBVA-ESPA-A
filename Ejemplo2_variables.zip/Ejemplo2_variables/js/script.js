/*
    Declarar variables de forma implicita y explicita
*/

// Declaracion implicita (no utilizamos la palabra var)
edad = 51;

// Declaracion explicita (utilizamos la palabra var)
var nombre = "Anabel";
var apellido = 'Vegas';

// + -> operador de concatenacion
document.write("Me llamo " + nombre + " " + apellido + " y tengo " + edad + " años" + "<br/>");

// cambiar el contenido de la variable edad
edad = 52;
document.write("Me llamo " + nombre + " " + apellido + " y tengo " + edad + " años" + "<br/>");

/* *******************   Tipos de datos ******************* */
var miVariable = "hola";
document.write(miVariable + " Tipo: " + typeof(miVariable) + "<br/>");

miVariable = 5.78;
document.write(miVariable + " Tipo: " + typeof(miVariable) + "<br/>");

miVariable = true;
document.write(miVariable + " Tipo: " + typeof(miVariable) + "<br/>");

miVariable = new Date();  // coge la fecha y hora actual del sistema
document.write(miVariable + " Tipo: " + typeof(miVariable) + "<br/>");

var otraVariable;
document.write(otraVariable + " Tipo: " + typeof(otraVariable) + "<br/>");

/* *******************  Bases numericas ******************** */
var num = 12345;
document.write(num + " en Decimal" + "<br/>");

num = 012345;
document.write(num + " en Octal" + "<br/>");

num = 0x12345;
document.write(num + " en Hexadecimal" + "<br/>");

// Todo dato introduccido por teclado es de tipo texto 
var numero1 = parseInt(window.prompt("Introduce un numero"));
var numero2 = window.prompt("Introduce otro numero");
alert(numero1 +  parseInt(numero2) ); 

// Conversiones implicitas
var datosPersonales = "Me llamo " + nombre + " " + apellido + " y tengo " + edad + " años";
document.write(datosPersonales + " Tipo: " + typeof(datosPersonales) + "<br/>");

var suma = 7 + true;
document.write(suma + " Tipo: " + typeof(suma) + "<br/>");

var base = parseFloat(window.prompt("Introduce base del triangulo"));
var altura = parseFloat(window.prompt("Introduce altura del triangulo"));
document.write("Area del triangulo es " + (base * altura / 2) + "<br/>");