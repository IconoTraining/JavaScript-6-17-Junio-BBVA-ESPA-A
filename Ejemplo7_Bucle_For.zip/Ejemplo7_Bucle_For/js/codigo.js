/* 
    EJEMPLO 1
    Mostrar los numeros del 1 al 10

for(var numero=1 ; numero <= 10 ; numero++ ){
    document.write(numero + "<br/>");
}
*/

/* 
    EJEMPLO 2
    Mostrar los numeros del 10 al 1

for(var numero=10; numero >= 1; numero--){
    document.write(numero + "<br/>");
}
*/

/* 
    EJEMPLO 3
    Mostrar los numeros del 1 al 20 de 2 de 2

for(var numero = 1; numero <= 20; numero += 2){
    document.write(numero + "<br/>");
}
*/

/*
    EJEMPLO 4
    Mostrar la tabla de multiplicar del numero 6

for (var i = 1; i <= 10; i++){
    document.write("6 x " + i + " = " + (6*i) + "<br/>");
}
*/

/*
    EJEMPLO 5
    Mostrar las tabla de multiplicar

for(var tabla=1; tabla<=10; tabla++){
    document.write("Tabla del numero " + tabla + "<br/>");
    for (var i = 1; i <= 10; i++){
        document.write(tabla + " x " + i + " = " + (tabla*i) + "<br/>");
    }
    document.write("<br/>");
}
*/

/* 
    EJEMPLO 6
    Mostrar los numeros que sean multiplo de 5 desde 100 hasta 0

for(var numero = 100; numero >= 0; numero--){
    if (numero % 5 == 0){
        document.write(numero + "<br/>");
    }
}
*/

/*
    EJEMPLO 7
    Recorrer un array

var numeros = [5,1,8,3,9,6,2,4];  
// indice comienza en 0 y termina longitud-1
// accede array[indice]

for(var i = 0; i < numeros.length; i++){
    document.write(numeros[i] + "<br/>");
}

for(var i in numeros){
    document.write(numeros[i] + "<br/>");
}

for(var num of numeros){
    document.write(num + "<br/>");
}
*/

/*
    EJEMPLO 8
    Sumar los numeros que esten en la posicion par del array (0,2,...)
*/
var numeros = [5,1,8,3,9,6,2,4];  
var suma = 0;
for(var i in numeros){
    if (i % 2 == 0){
        document.write(numeros[i] + " ");
        suma += numeros[i];
    }
}
document.write("Suma: " + suma + "<br/>");
