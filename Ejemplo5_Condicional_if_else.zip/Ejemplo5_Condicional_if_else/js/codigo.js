/*
    EJEMPLO 1
    Comprobar si un numero es par o impar

var numero = 8;
if (numero % 2 == 0){
    alert("Numero es par");
} else {
    alert("Numero es impar");
}
*/ 

/*
    EJEMPLO 2
    Dados 2 numeros mostrar cual es el mayor de los dos o si son iguales
 
var num1 = 3;
var num2 = 7;

if (num1 > num2){
    alert(num1 + " es el mayor");
} else if (num2 > num1){
    alert(num2 + " es el mayor");
} else {
    alert("Ambos numeros son iguales");
}
*/

/*
    EJEMPLO 3
    Preguntar al usuario cual es la contraseña, si es "curso" le diremos ok

var pw = window.prompt("Introduce contraseña: ");
if (pw == "curso"){
    alert("Contraseña correcta");
}
*/

/*
    EJEMPLO 4
    Hallar una renta: Capital x redito x tiempo / 1200
    El capital y el tiempo (en meses) se lo pedimos al usuario
    El redito se aplica de la siguiente forma:
        Si el tiempo es menor o igual a 24 meses, se aplica el 5%
        Si el tiempo es menor o igual a 60 meses, se aplica el 8%
        Si el tiempo es mayor a 60 meses, se aplica el 10%

var capital = parseFloat(window.prompt("Introduce capital"));
var tiempo = parseInt(window.prompt("Introduce tiempo en meses:"));
var redito = 0;

if (tiempo <= 24){
    redito = 5;
} else if (tiempo <= 60){
    redito = 8;
} else {
    redito = 10;
}

var renta = capital * redito * tiempo / 1200;
alert("Renta: " + renta);
*/

/*
    EJEMPLO 5
    Se va a subir el sueldo a los empleados de la siguiente manera:
        Los que cobren actualmente menos de 15000€ se les sube el 15%
        Los que cobren mas o 15000€ se les sube el 12%

    ademas:
        si son mujeres tienen un 2% adicional independientemente de su sueldo
        Por cada hijo tienen otro 1% adicional, hombres y mujeres.
    
    Solicitar al usuario los siguientes datos: sueldo actual, sexo y numero de hijos
    Calcular su nuevo sueldo y mostrarlo
*/

var sueldo_actual = parseFloat(window.prompt("Introduce sueldo actual"));
var sexo = window.prompt("Introduce sexo (h/m):");
var hijos = parseInt(window.prompt("Introduce numero de hijos"));

var sueldo_actualizado = 0;

if (sueldo_actual < 15000){
    sueldo_actualizado = sueldo_actual + (sueldo_actual * 15/100);
} else {
    sueldo_actualizado = sueldo_actual + (sueldo_actual * 12/100);
}

if (sexo == 'm' || sexo == 'M' || sexo == 'mujer' || sexo == 'MUJER'){
    //sueldo_actualizado = sueldo_actualizado + (sueldo_actualizado * 2/100);
    sueldo_actualizado += (sueldo_actualizado * 2/100);
}

if (hijos > 0){
    sueldo_actualizado += (sueldo_actualizado * hijos/100);
}

alert("Tu nuevo sueldo es: " + sueldo_actualizado);