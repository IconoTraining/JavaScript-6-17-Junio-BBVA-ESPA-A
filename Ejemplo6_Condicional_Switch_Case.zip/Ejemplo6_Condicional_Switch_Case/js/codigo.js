/*
    EJEMPLO 1
    Solicitar sexo al usuario y decir si es hombre o mujer
*/

var sexo = window.prompt("Introduce sexo (h/m):");
switch (sexo) {
    case "h":
    case "H":
    case "hombre":
    case "HOMBRE":
    case "Hombre":
        alert("Eres hombre");
        break;

    case "m":
    case "M":
    case "mujer":
    case "Mujer":
    case "MUJER":
        alert("Eres mujer");
        break;  
    
    default:
        alert("No reconocido");
        break;
}

/*
    EJEMPLO 2
    Solicitar una nota numerica entera 
    Mostrar 0-4 suspenso, 5 aprobado, 6 bien, 7-8 notable, 9-10 sobresaliente
*/


/*
    EJEMPLO 3
    pedir un numero del 1 al 7 y decir a que dia de la semana corresponde
*/