/*
    EJEMPLO 1
    Solicitar sexo al usuario y decir si es hombre o mujer


var sexo = window.prompt("Introduce sexo (h/m):");
switch (sexo) {
    case "h":
    case "H":
    case "hombre":
    case "HOMBRE":
    case "Hombre":
        alert("Eres hombre");
        break;

    case "m":
    case "M":
    case "mujer":
    case "Mujer":
    case "MUJER":
        alert("Eres mujer");
        break;  
    
    default:
        alert("No reconocido");
        break;
}
*/

/*
    EJEMPLO 2
    Solicitar una nota numerica entera 
    Mostrar 0-4 suspenso, 5 aprobado, 6 bien, 7-8 notable, 9-10 sobresaliente

var nota = parseInt(window.prompt("Introduce nota numerica (0-10):"));
switch(nota){
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
        alert("Suspenso");
        break;
    case 5:
        alert("Aprobado");
        break;
    case 6:
        alert("Bien");
        break;
    case 7:
    case 8:
        alert("Notable");
        break;
    case 9:
    case 10:
        alert("Sobresaliente");
        break;
    default:
        alert("Nota no valida");        
}
*/

/*
    EJEMPLO 3
    pedir un numero del 1 al 7 y decir a que dia de la semana corresponde
*/
var dia = parseInt(window.prompt("Introduce numero del 1-7:"));
switch (dia) {
    case 1:
        alert("Es lunes");
        break;
    case 2:
        alert("Es martes");
        break;
    case 3:
        alert("Es miercoles");
        break;
    case 4:
        alert("Es jueves");
        break;
    case 5:
        alert("Es viernes");
        break;
    case 6:
        alert("Es sabado");
        break;
    case 7:
        alert("Domingo");
        break;    
    default:
        alert("Dia no valido");
}